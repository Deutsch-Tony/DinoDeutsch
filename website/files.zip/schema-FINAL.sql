-- ═══════════════════════════════════════════════════════════
--  DinoDeutsch KI Agent — FINAL MVP Schema
--  Chạy toàn bộ file này trong Supabase SQL Editor
--  (một lần duy nhất, thứ tự đúng)
-- ═══════════════════════════════════════════════════════════

-- ── 1. USER MEMORY ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS user_memory (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
  level           text    DEFAULT 'A1',
  xp              int     DEFAULT 0,
  learned_words   int     DEFAULT 0,
  weak_topics     text[]  DEFAULT '{}',
  strong_topics   text[]  DEFAULT '{}',
  common_errors   text[]  DEFAULT '{}',
  teaching_style  text    DEFAULT 'mixed',
  learning_speed  text    DEFAULT 'normal',
  difficulty      int     DEFAULT 3,
  session_summary text    DEFAULT '',
  total_sessions  int     DEFAULT 0,
  streak_days     int     DEFAULT 0,
  notes           text    DEFAULT '',
  last_seen       timestamptz DEFAULT now(),
  created_at      timestamptz DEFAULT now()
);
ALTER TABLE user_memory ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own memory" ON user_memory FOR ALL USING (auth.uid() = user_id);

-- ── 2. CHAT MESSAGES ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS chat_messages (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  role       text CHECK (role IN ('user', 'assistant')),
  content    text NOT NULL,
  topic      text,
  mode       text,
  xp_gained  int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own messages" ON chat_messages FOR ALL USING (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS chat_messages_user_time ON chat_messages(user_id, created_at DESC);

-- ── 3. MESSAGE FEEDBACK (👍👎) ────────────────────────────────
CREATE TABLE IF NOT EXISTS message_feedback (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id             uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  message_hash        text NOT NULL,
  message_text        text,
  topic               text,
  mode                text,
  rating              smallint CHECK (rating IN (-1, 1)),
  explanation_variant text,
  created_at          timestamptz DEFAULT now()
);
ALTER TABLE message_feedback ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own feedback" ON message_feedback FOR ALL USING (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS feedback_rating ON message_feedback(rating, topic);

-- ── 4. KNOWLEDGE BASE ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS knowledge_base (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  topic         text NOT NULL,
  subtopic      text DEFAULT '',
  content       text NOT NULL,
  source_url    text DEFAULT '',
  quality_score float DEFAULT 0.5,
  times_used    int  DEFAULT 0,
  times_helpful int  DEFAULT 0,
  tags          text[] DEFAULT '{}',
  created_by    text DEFAULT 'agent',
  created_at    timestamptz DEFAULT now(),
  updated_at    timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS kb_topic ON knowledge_base(topic, quality_score DESC);

-- ── 5. A/B TESTS (backend only, no UI) ───────────────────────
CREATE TABLE IF NOT EXISTS ab_tests (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  test_name    text NOT NULL,
  variant      text NOT NULL,
  topic        text,
  prompt_snippet text,
  impressions  int   DEFAULT 0,
  thumbs_up    int   DEFAULT 0,
  thumbs_down  int   DEFAULT 0,
  score        float GENERATED ALWAYS AS (
    CASE WHEN impressions = 0 THEN 0
    ELSE (thumbs_up::float - thumbs_down) / impressions END
  ) STORED,
  active       boolean DEFAULT true,
  winner       boolean DEFAULT false,
  created_at   timestamptz DEFAULT now(),
  UNIQUE(test_name, variant)
);

-- ── 6. GLOBAL ERROR PATTERNS ─────────────────────────────────
CREATE TABLE IF NOT EXISTS global_error_patterns (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  error_text     text NOT NULL UNIQUE,
  category       text,
  occurrences    int DEFAULT 1,
  affected_users int DEFAULT 1,
  best_fix       text,
  last_seen      timestamptz DEFAULT now(),
  created_at     timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS errors_occ ON global_error_patterns(occurrences DESC);

-- ── 7. SKILL NODES (basic tracking) ──────────────────────────
CREATE TABLE IF NOT EXISTS skill_nodes (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  skill_id    text NOT NULL,
  category    text NOT NULL,
  level       text DEFAULT 'A1',
  status      text DEFAULT 'learning',  -- learning | mastered
  confidence  float DEFAULT 0.0,
  attempts    int   DEFAULT 0,
  correct     int   DEFAULT 0,
  last_tested timestamptz,
  created_at  timestamptz DEFAULT now(),
  UNIQUE(user_id, skill_id)
);
ALTER TABLE skill_nodes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own skills" ON skill_nodes FOR ALL USING (auth.uid() = user_id);

-- ── 8. PROMPT VERSIONS (auto-improvement) ────────────────────
CREATE TABLE IF NOT EXISTS prompt_versions (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  version     int  NOT NULL,
  prompt_text text NOT NULL,
  reason      text DEFAULT '',
  avg_rating  float DEFAULT 0,
  active      boolean DEFAULT false,
  created_at  timestamptz DEFAULT now()
);
INSERT INTO prompt_versions (version, prompt_text, reason, active)
VALUES (1, 'BASE_PROMPT_v1 — see worker.js', 'Initial version', true)
ON CONFLICT DO NOTHING;

-- ── 9. AGENT DIARY ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS agent_diary (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date           date NOT NULL UNIQUE,
  total_sessions int  DEFAULT 0,
  avg_rating     float DEFAULT 0,
  top_errors     text[] DEFAULT '{}',
  top_topics     text[] DEFAULT '{}',
  reflection     text DEFAULT '',
  improvements   text[] DEFAULT '{}',
  created_at     timestamptz DEFAULT now()
);

-- ── HELPER FUNCTION: upsert_memory ───────────────────────────
CREATE OR REPLACE FUNCTION upsert_memory(
  p_user_id     uuid,
  p_xp_add      int     DEFAULT 0,
  p_weak        text[]  DEFAULT null,
  p_strong      text[]  DEFAULT null,
  p_errors      text[]  DEFAULT null,
  p_notes       text    DEFAULT null,
  p_level       text    DEFAULT null,
  p_words_add   int     DEFAULT 0,
  p_style       text    DEFAULT null,
  p_speed       text    DEFAULT null,
  p_difficulty  int     DEFAULT null,
  p_summary     text    DEFAULT null
) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO user_memory (
    user_id, xp, weak_topics, strong_topics, common_errors,
    notes, level, learned_words, teaching_style, learning_speed,
    difficulty, session_summary, total_sessions
  ) VALUES (
    p_user_id, p_xp_add,
    COALESCE(p_weak,'{}'), COALESCE(p_strong,'{}'), COALESCE(p_errors,'{}'),
    COALESCE(p_notes,''), COALESCE(p_level,'A1'), p_words_add,
    COALESCE(p_style,'mixed'), COALESCE(p_speed,'normal'),
    COALESCE(p_difficulty,3), COALESCE(p_summary,''), 1
  )
  ON CONFLICT (user_id) DO UPDATE SET
    xp              = user_memory.xp + p_xp_add,
    learned_words   = user_memory.learned_words + p_words_add,
    weak_topics     = CASE WHEN p_weak    IS NOT NULL THEN p_weak    ELSE user_memory.weak_topics   END,
    strong_topics   = CASE WHEN p_strong  IS NOT NULL THEN p_strong  ELSE user_memory.strong_topics END,
    common_errors   = CASE WHEN p_errors  IS NOT NULL THEN p_errors  ELSE user_memory.common_errors END,
    notes           = CASE WHEN p_notes   IS NOT NULL THEN p_notes   ELSE user_memory.notes         END,
    level           = CASE WHEN p_level   IS NOT NULL THEN p_level   ELSE user_memory.level         END,
    teaching_style  = CASE WHEN p_style   IS NOT NULL THEN p_style   ELSE user_memory.teaching_style END,
    learning_speed  = CASE WHEN p_speed   IS NOT NULL THEN p_speed   ELSE user_memory.learning_speed END,
    difficulty      = CASE WHEN p_difficulty IS NOT NULL THEN p_difficulty ELSE user_memory.difficulty END,
    session_summary = CASE WHEN p_summary IS NOT NULL THEN p_summary ELSE user_memory.session_summary END,
    total_sessions  = user_memory.total_sessions + 1,
    last_seen       = now();
END;
$$;
