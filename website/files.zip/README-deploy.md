# DinoDeutsch KI Agent — Deploy Guide

## Tổng quan

```
dinodeutsch.pages.dev          ← Cloudflare Pages (HTML files)
    └── /assistant             ← assistant-FINAL.html
dino-agent.workers.dev         ← Cloudflare Worker (API)
your-project.supabase.co       ← Supabase (DB + Auth)
```

---

## Bước 1 — Supabase

### 1.1 Tạo project
→ https://supabase.com → New project → đặt tên "dinodeutsch"

### 1.2 Chạy schema
Vào **SQL Editor** → paste toàn bộ file `schema-FINAL.sql` → Run

### 1.3 Lấy credentials
→ Settings → API → Copy:
- **Project URL**: `https://xxx.supabase.co`
- **anon/public key**: `eyJ...`

### 1.4 Bật Auth (tùy chọn)
→ Authentication → Providers → Email (bật, tắt "Confirm email" khi dev)

---

## Bước 2 — Cloudflare Worker

### 2.1 Cài Wrangler
```bash
npm install -g wrangler
wrangler login
```

### 2.2 Deploy worker
```bash
# Trong folder chứa worker-mvp.js và wrangler.toml
wrangler deploy
```

### 2.3 Set secrets (QUAN TRỌNG — không dùng .env)
```bash
wrangler secret put ANTHROPIC_API_KEY
# → nhập API key từ console.anthropic.com

wrangler secret put SUPABASE_URL
# → nhập https://xxx.supabase.co

wrangler secret put SUPABASE_ANON_KEY
# → nhập eyJ...
```

### 2.4 Lấy Worker URL
Sau khi deploy xong, Wrangler sẽ in ra:
```
https://dinodeutsch-agent.YOUR_SUBDOMAIN.workers.dev
```
Copy URL này → dùng ở Bước 3.

---

## Bước 3 — Cấu hình Frontend

Mở `assistant-FINAL.html`, tìm phần cấu hình (dòng ~450):

```javascript
const WORKER_URL = 'https://dinodeutsch-agent.YOUR_SUBDOMAIN.workers.dev';
const SB_URL     = 'https://xxx.supabase.co';
const SB_KEY     = 'eyJ...';
```

Thay 3 giá trị này bằng credentials thật.

---

## Bước 4 — Deploy lên Cloudflare Pages

### Option A: Kéo thả (đơn giản nhất)
→ https://pages.cloudflare.com → Create project → Upload
→ Upload tất cả file HTML vào folder → Deploy

### Option B: Connect GitHub (tự động deploy)
```bash
# Cấu trúc repo tối thiểu:
dinodeutsch/
├── assistant.html     ← đổi tên từ assistant-FINAL.html
├── offline.html
└── manifest.json      ← (tùy chọn, cho PWA)
```
→ Pages → Connect GitHub repo → Framework: None → Build output: / → Deploy

---

## Bước 5 — Test

Mở `https://dinodeutsch.pages.dev/assistant` và kiểm tra:

- [ ] Banner cấu hình biến mất (WORKER_URL đúng)
- [ ] Hỏi "Xin chào" → bot trả lời (Worker hoạt động)
- [ ] Đăng ký tài khoản → XP hiện lên sidebar (Supabase OK)
- [ ] Gõ "Kế hoạch hôm nay" → bot gọi get_memory + plan_session
- [ ] Bấm 👍 sau câu trả lời → không có lỗi console

---

## File list (tất cả files cần thiết)

| File | Dùng để | Bắt buộc |
|------|---------|----------|
| `assistant-FINAL.html` | Trang chính | ✅ |
| `worker-mvp.js` | Cloudflare Worker | ✅ |
| `schema-FINAL.sql` | Supabase DB | ✅ |
| `wrangler.toml` | Deploy config | ✅ |
| `offline.html` | Trang offline fallback | Tùy chọn |
| `manifest.json` | PWA (cài app) | Tùy chọn |
| `service-worker.js` | PWA offline | Tùy chọn |
| `DEFERRED-FEATURES.txt` | Roadmap | Tham khảo |

---

## Chi phí ước tính

| Service | Free tier | Hết free khi nào |
|---------|-----------|-----------------|
| Cloudflare Pages | Miễn phí | Không giới hạn |
| Cloudflare Workers | 100k req/ngày | >100k req/ngày |
| Supabase | 500MB + 50k rows | >500MB data |
| Anthropic API | $0 — trả theo dùng | ~$0.003/tin nhắn |

**Thực tế:** $0-5/tháng cho giai đoạn đầu.

---

## Troubleshooting

**Bot không trả lời:**
→ Mở DevTools → Console → xem lỗi fetch
→ Kiểm tra Worker URL đúng không
→ Kiểm tra ANTHROPIC_API_KEY còn credit không

**XP không lưu:**
→ Kiểm tra Supabase URL và anon key
→ Kiểm tra user đã đăng nhập chưa
→ Xem Supabase → Table Editor → user_memory có row không

**Worker lỗi 500:**
→ `wrangler tail` để xem log realtime
```bash
wrangler tail dinodeutsch-agent
```

**Schema lỗi khi chạy:**
→ Chạy từng block SQL riêng (tách bởi dấu --)
→ Nếu table đã tồn tại: `DROP TABLE IF EXISTS tên_table CASCADE;` rồi chạy lại
