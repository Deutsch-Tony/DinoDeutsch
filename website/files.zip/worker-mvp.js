// DinoDeutsch KI Agent — worker.js (MVP Clean)
// Secrets: ANTHROPIC_API_KEY, SUPABASE_URL, SUPABASE_ANON_KEY

const CORS = {
  'Access-Control-Allow-Origin':  'https://dinodeutsch.pages.dev',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json',
};

const BASE_SYSTEM = `Bạn là KI Agent của DinoDeutsch — giáo viên tiếng Đức thông minh cho người Việt.

PHONG CÁCH: Ấm áp, chủ động, chính xác. Dạy tiếng Việt, ví dụ tiếng Đức. LUÔN ghi der/die/das.

KHI BẮT ĐẦU (có user_id): get_memory → plan_session → thực hiện. Không hỏi — tự lập kế hoạch.
KHI DẠY NGỮ PHÁP: get_ab_variant → predict_errors → cảnh báo trước.
KHI DẠY TỪ VỰNG: Dạy xong → update_skill.
KHI HỌC VIÊN SAI 2 LẦN: update_difficulty(struggling).
KHI HỌC VIÊN ĐÚNG 3 LẦN: update_difficulty(excelling).
KHI CẦN THÔNG TIN MỚI: web_search.

SAU MỖI REPLY: <!--M:{"w":[],"s":[],"e":[],"n":0,"note":""}-->`;

const TOOLS = [
  { name:'get_memory', description:'Đọc hồ sơ học tập của học viên.', input_schema:{ type:'object', properties:{ user_id:{type:'string'} }, required:['user_id'] } },
  { name:'update_memory', description:'Cập nhật hồ sơ sau buổi học.', input_schema:{ type:'object', properties:{ user_id:{type:'string'}, xp_add:{type:'number'}, weak_topics:{type:'array',items:{type:'string'}}, strong_topics:{type:'array',items:{type:'string'}}, errors:{type:'array',items:{type:'string'}}, words_add:{type:'number'}, notes:{type:'string'}, level:{type:'string'}, teaching_style:{type:'string'}, session_summary:{type:'string'} }, required:['user_id'] } },
  { name:'web_search', description:'Tìm kiếm web thật: DW tin tức, kiến thức tiếng Đức.', input_schema:{ type:'object', properties:{ query:{type:'string'}, source:{type:'string',enum:['general','dw','nachrichtenleicht']} }, required:['query'] } },
  { name:'get_knowledge', description:'Lấy kiến thức tốt nhất từ knowledge base.', input_schema:{ type:'object', properties:{ topic:{type:'string'}, level:{type:'string'} }, required:['topic'] } },
  { name:'save_knowledge', description:'Lưu kiến thức tốt vào knowledge base.', input_schema:{ type:'object', properties:{ topic:{type:'string'}, content:{type:'string'} }, required:['topic','content'] } },
  { name:'get_ab_variant', description:'Lấy variant A/B test khi dạy ngữ pháp.', input_schema:{ type:'object', properties:{ topic:{type:'string'} }, required:['topic'] } },
  { name:'predict_errors', description:'Dự đoán lỗi học viên sắp mắc.', input_schema:{ type:'object', properties:{ current_topic:{type:'string'}, level:{type:'string'}, known_errors:{type:'array',items:{type:'string'}} }, required:['current_topic','level'] } },
  { name:'update_difficulty', description:'Điều chỉnh độ khó theo performance.', input_schema:{ type:'object', properties:{ user_id:{type:'string'}, performance:{type:'string',enum:['struggling','excelling']}, current_difficulty:{type:'number'} }, required:['performance'] } },
  { name:'plan_session', description:'Lập kế hoạch buổi học từ hồ sơ.', input_schema:{ type:'object', properties:{ level:{type:'string'}, weak_topics:{type:'array',items:{type:'string'}}, last_session:{type:'string'}, available_time:{type:'number'} }, required:['level'] } },
  { name:'generate_exercise', description:'Tạo bài tập cá nhân hóa.', input_schema:{ type:'object', properties:{ weak_topics:{type:'array',items:{type:'string'}}, level:{type:'string',enum:['A1','A2','B1','B2','C1']}, type:{type:'string',enum:['fill_blank','translate','error_fix','word_order','multiple_choice','mixed']}, count:{type:'number'}, difficulty:{type:'number'} }, required:['level'] } },
  { name:'create_roadmap', description:'Tạo lộ trình học theo tuần.', input_schema:{ type:'object', properties:{ current_level:{type:'string'}, target_level:{type:'string'}, weak_topics:{type:'array',items:{type:'string'}}, minutes_per_day:{type:'number'}, weeks:{type:'number'} }, required:['current_level','target_level'] } },
  { name:'find_media', description:'Tìm bài hát/podcast tiếng Đức phù hợp cấp độ.', input_schema:{ type:'object', properties:{ level:{type:'string',enum:['A1','A2','B1','B2','C1']}, type:{type:'string',enum:['song','podcast']} }, required:['level','type'] } },
  { name:'grade_and_next', description:'Chấm bài viết + tạo bài tiếp theo.', input_schema:{ type:'object', properties:{ text:{type:'string'}, level:{type:'string'}, difficulty:{type:'number'} }, required:['text','level'] } },
  { name:'update_skill', description:'Cập nhật trạng thái skill sau bài tập.', input_schema:{ type:'object', properties:{ user_id:{type:'string'}, skill_id:{type:'string'}, category:{type:'string'}, correct:{type:'boolean'}, quality:{type:'number'} }, required:['user_id','skill_id','category','correct'] } },
];

async function exec(name, input, env, userId, sbToken) {
  const H = { apikey:env.SUPABASE_ANON_KEY, Authorization:`Bearer ${sbToken||env.SUPABASE_ANON_KEY}`, 'Content-Type':'application/json' };
  const sb = (p,o={}) => fetch(`${env.SUPABASE_URL}${p}`,{...o,headers:{...H,...(o.headers||{})}});

  switch(name) {
    case 'get_memory': {
      const r = await sb(`/rest/v1/user_memory?user_id=eq.${input.user_id}&select=*&limit=1`);
      const d = await r.json();
      return d?.[0]||{level:'A1',xp:0,learned_words:0,weak_topics:[],strong_topics:[],common_errors:[],teaching_style:'mixed',difficulty:3,total_sessions:0,session_summary:''};
    }
    case 'update_memory': {
      await sb(`/rest/v1/rpc/upsert_memory`,{method:'POST',body:JSON.stringify({
        p_user_id:input.user_id,p_xp_add:input.xp_add||0,
        p_weak:input.weak_topics?.length?input.weak_topics:null,
        p_strong:input.strong_topics?.length?input.strong_topics:null,
        p_errors:input.errors?.length?input.errors:null,
        p_notes:input.notes||null,p_level:input.level||null,
        p_words_add:input.words_add||0,p_style:input.teaching_style||null,
        p_summary:input.session_summary||null
      })});
      if(input.errors?.length) for(const e of input.errors)
        await sb(`/rest/v1/global_error_patterns`,{method:'POST',headers:{Prefer:'resolution=merge-duplicates'},body:JSON.stringify({error_text:e,occurrences:1})}).catch(()=>{});
      return {ok:true};
    }
    case 'web_search': {
      try {
        if(['dw','news'].includes(input.source||'')) {
          const x = await (await fetch('https://rss.dw.com/rdf/rss-de-all')).text();
          const items = [...x.matchAll(/<item>[\s\S]*?<title>(.*?)<\/title>[\s\S]*?<link>(.*?)<\/link>[\s\S]*?<description>(.*?)<\/description>[\s\S]*?<\/item>/g)]
            .slice(0,4).map(m=>({title:m[1].replace(/<!\[CDATA\[|\]\]>/g,'').trim(),url:m[2].trim(),desc:m[3].replace(/<!\[CDATA\[|\]\]>/g,'').replace(/<[^>]+>/g,'').trim().slice(0,200)}));
          return {ok:true,source:'DW',results:items};
        }
        const d = await (await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(input.query)}&format=json&no_html=1&skip_disambig=1`)).json();
        return {ok:true,source:'Web',results:[{title:d.Heading||input.query,desc:d.Abstract||'',url:d.AbstractURL||''},...(d.RelatedTopics||[]).slice(0,3).map(t=>({title:t.Text?.slice(0,60)||'',desc:t.Text||'',url:t.FirstURL||''}))].filter(r=>r.title)};
      } catch(e){return{ok:false,error:e.message};}
    }
    case 'get_knowledge': {
      const d = await (await sb(`/rest/v1/knowledge_base?topic=eq.${encodeURIComponent(input.topic)}&quality_score=gte.0.5&order=quality_score.desc&limit=2&select=topic,content,quality_score`)).json();
      return {ok:true,found:(d||[]).length>0,knowledge:d||[]};
    }
    case 'save_knowledge': {
      await sb(`/rest/v1/knowledge_base`,{method:'POST',headers:{Prefer:'return=minimal'},body:JSON.stringify({topic:input.topic,content:input.content,created_by:'agent'})});
      return {ok:true};
    }
    case 'get_ab_variant': {
      const tn = `explain_${input.topic.toLowerCase().replace(/\s+/g,'_').slice(0,25)}_v1`;
      const tests = await (await sb(`/rest/v1/ab_tests?test_name=eq.${tn}&active=eq.true&select=variant,impressions`)).json()||[];
      if(!tests.length){
        await sb(`/rest/v1/ab_tests`,{method:'POST',headers:{Prefer:'return=minimal'},body:JSON.stringify([{test_name:tn,variant:'A',topic:input.topic,prompt_snippet:'rule-first'},{test_name:tn,variant:'B',topic:input.topic,prompt_snippet:'example-first'}])});
        return {test_name:tn,variant:'A',approach:'rule-first'};
      }
      const c = tests.sort((a,b)=>a.impressions-b.impressions)[0];
      await sb(`/rest/v1/ab_tests?test_name=eq.${tn}&variant=eq.${c.variant}`,{method:'PATCH',headers:{Prefer:'return=minimal'},body:JSON.stringify({impressions:(c.impressions||0)+1})}).catch(()=>{});
      return {test_name:tn,variant:c.variant,approach:c.variant==='A'?'rule-first':'example-first'};
    }
    case 'predict_errors': {
      const t=(input.current_topic||'').toLowerCase(), k=input.known_errors||[];
      const P={kasus:['Nhầm Akkusativ/Dativ sau giới từ hai nghĩa','Quên chia mạo từ theo cách'],artikel:['Quên der/die/das','Nhầm giới từ khi chia cách'],verb:['Quên chia động từ theo ngôi','Nhầm vị trí động từ cuối mệnh đề phụ'],perfekt:['Nhầm sein/haben','Quên Partizip II bất quy tắc'],wortstellung:['Đặt động từ sai mệnh đề phụ','Quên đảo ngữ khi trạng ngữ đầu câu'],adjektiv:['Quên chia đuôi tính từ'],präposition:['Nhầm an/auf/in với Dativ/Akkusativ']};
      const preds=[];
      for(const[k2,errs] of Object.entries(P)) if(t.includes(k2)||k.some(e=>e.toLowerCase().includes(k2))) errs.forEach(e=>preds.push({error:e,tip:`Kiểm tra ${k2}`}));
      if(['A1','A2'].includes(input.level)) preds.push({error:'Quên chia sein/haben',tip:'ich bin/habe, du bist/hast'});
      return {ok:true,predictions:preds.slice(0,3)};
    }
    case 'update_difficulty': {
      const c=input.current_difficulty||5, nd=input.performance==='excelling'?Math.min(10,c+1):Math.max(1,c-1);
      if(sbToken&&userId) await sb(`/rest/v1/user_memory?user_id=eq.${userId}`,{method:'PATCH',headers:{Prefer:'return=minimal'},body:JSON.stringify({difficulty:nd})}).catch(()=>{});
      return {ok:true,new_difficulty:nd,message:input.performance==='excelling'?`🚀 Tăng độ khó lên ${nd}/10`:`💪 Về ${nd}/10 để củng cố`};
    }
    case 'plan_session': {
      const{level,weak_topics=[],last_session='',available_time=30}=input;
      return {ok:true,plan:[last_session&&{a:'review',min:5,d:`Ôn: ${last_session.slice(0,60)}`},weak_topics.length&&{a:'focus',min:Math.floor(available_time*.4),d:`Luyện: ${weak_topics.slice(0,2).join(', ')}`},{a:'new',min:Math.floor(available_time*.35),d:'Học mới'},{a:'practice',min:Math.floor(available_time*.2),d:'Bài tập'}].filter(Boolean)};
    }
    case 'generate_exercise': {
      const w=(input.weak_topics||['ngữ pháp']).join(', ');
      return {ok:true,level:input.level,instruction:`Tạo ${input.count||5} bài tập ${input.type||'mixed'} cấp ${input.level} (độ khó ${input.difficulty||5}/10), tập trung: ${w}. Kèm đáp án đầy đủ.`};
    }
    case 'create_roadmap': {
      return {ok:true,instruction:`Tạo lộ trình ${input.weeks||8} tuần từ ${input.current_level}→${input.target_level}, ${input.minutes_per_day||30} phút/ngày, ưu tiên: ${(input.weak_topics||[]).join(', ')||'cân bằng'}. Chi tiết từng tuần với mục tiêu cụ thể.`};
    }
    case 'find_media': {
      const db={song:{A1:[{t:'Alle meine Entchen',a:'Traditional'}],A2:[{t:'99 Luftballons',a:'Nena'}],B1:[{t:'Zusammen',a:'Beatrice Egli'}],B2:[{t:'Du hast',a:'Rammstein'}],C1:[{t:'Über den Wolken',a:'Reinhard Mey'}]},podcast:{A1:[{t:'Slow German',h:'Annik Rubens',u:'slowgerman.com'}],A2:[{t:'Deutsch warum nicht',h:'DW',u:'dw.com'}],B1:[{t:'Auf Deutsch gesagt',h:'BR',u:'br.de'}],B2:[{t:'Podcast-WG',h:'Spotify',u:'spotify.com'}],C1:[{t:'Zeitzeichen',h:'WDR',u:'wdr.de'}]}};
      return {ok:true,results:db[input.type]?.[input.level]||[]};
    }
    case 'grade_and_next': {
      return {ok:true,instruction:`Chấm bài (Ngữ pháp/3, Từ vựng/3, Mạch lạc/2, Phong cách/2). Hiện điểm rõ ràng, chỉ ra tối đa 3 lỗi + giải thích tại sao sai, đưa phiên bản cải thiện. Sau đó tạo bài tiếp khó hơn 1 bậc tập trung điểm yếu.\n\nBài:\n${input.text}`};
    }
    case 'update_skill': {
      if(!sbToken) return {ok:false};
      const cur=(await(await sb(`/rest/v1/skill_nodes?user_id=eq.${input.user_id}&skill_id=eq.${input.skill_id}&select=attempts,correct&limit=1`)).json())?.[0]||{attempts:0,correct:0};
      const na=cur.attempts+1,nc=cur.correct+(input.correct?1:0),conf=nc/na,status=conf>=0.85&&na>=3?'mastered':'learning';
      await sb(`/rest/v1/skill_nodes`,{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:JSON.stringify({user_id:input.user_id,skill_id:input.skill_id,category:input.category,status,confidence:conf,attempts:na,correct:nc,last_tested:new Date().toISOString()})});
      return {ok:true,status,confidence:conf};
    }
    default: return {error:`Unknown: ${name}`};
  }
}

async function runAgent(messages, env, userId, sbToken, mode, sessionState) {
  let system = BASE_SYSTEM;
  try {
    const rows = await (await fetch(`${env.SUPABASE_URL}/rest/v1/prompt_versions?active=eq.true&order=version.desc&limit=1`,{headers:{apikey:env.SUPABASE_ANON_KEY,Authorization:`Bearer ${env.SUPABASE_ANON_KEY}`}})).json();
    if(rows?.[0]?.version>1) system=rows[0].prompt_text;
  } catch(_){}
  if(mode) system+=`\n\nCHẾ ĐỘ: ${mode}`;
  if(sessionState?.difficulty) system+=`\nĐỘ KHÓ: ${sessionState.difficulty}/10`;

  let msgs=[...messages], reply='', memUpdate=null;
  const toolsUsed=[], toolResults={};
  for(let i=0;i<8;i++){
    const res=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'Content-Type':'application/json','x-api-key':env.ANTHROPIC_API_KEY,'anthropic-version':'2023-06-01'},body:JSON.stringify({model:'claude-sonnet-4-20250514',max_tokens:2000,system,tools:TOOLS,messages:msgs})});
    const data=await res.json();
    if(!res.ok) throw new Error(data.error?.message||'API error');
    if(data.stop_reason==='tool_use'){
      const uses=data.content.filter(b=>b.type==='tool_use'),results=[];
      for(const u of uses){toolsUsed.push(u.name);const r=await exec(u.name,u.input,env,userId,sbToken);toolResults[u.name]=r;results.push({type:'tool_result',tool_use_id:u.id,content:JSON.stringify(r)});}
      msgs=[...msgs,{role:'assistant',content:data.content},{role:'user',content:results}];continue;
    }
    reply=data.content.find(b=>b.type==='text')?.text||'';
    const m=reply.match(/<!--M:(.*?)-->/s);
    if(m){try{memUpdate=JSON.parse(m[1]);}catch(_){}reply=reply.replace(/<!--M:.*?-->/s,'').trim();}
    break;
  }
  return {reply,toolsUsed,toolResults,memUpdate};
}

export default {
  async fetch(request, env) {
    if(request.method==='OPTIONS') return new Response(null,{status:204,headers:CORS});
    if(request.method!=='POST') return new Response('Method not allowed',{status:405,headers:CORS});
    try {
      const body=await request.json();
      const{action,messages,topic,mode,userId,supabaseToken,sessionState}=body;
      const H={apikey:env.SUPABASE_ANON_KEY,Authorization:`Bearer ${supabaseToken||env.SUPABASE_ANON_KEY}`,'Content-Type':'application/json'};

      if(action==='feedback'){
        await fetch(`${env.SUPABASE_URL}/rest/v1/message_feedback`,{method:'POST',headers:{...H,Prefer:'return=minimal'},body:JSON.stringify({user_id:userId,message_hash:body.hash,message_text:body.text?.slice(0,200),rating:body.rating,topic:body.topic,mode:body.mode,explanation_variant:body.ab_variant})});
        if(body.ab_variant){const[tn,v]=body.ab_variant.split('::');if(tn&&v){const f=body.rating===1?'thumbs_up':'thumbs_down';const rows=await(await fetch(`${env.SUPABASE_URL}/rest/v1/ab_tests?test_name=eq.${tn}&variant=eq.${v}&select=${f}&limit=1`,{headers:H})).json()||[];if(rows[0])await fetch(`${env.SUPABASE_URL}/rest/v1/ab_tests?test_name=eq.${tn}&variant=eq.${v}`,{method:'PATCH',headers:{...H,Prefer:'return=minimal'},body:JSON.stringify({[f]:(rows[0][f]||0)+1})});}}
        return new Response(JSON.stringify({ok:true}),{headers:CORS});
      }

      const{reply,toolsUsed,toolResults,memUpdate}=await runAgent(messages,env,userId,supabaseToken,mode,sessionState);

      if(userId&&supabaseToken&&memUpdate)
        await exec('update_memory',{user_id:userId,xp_add:10,weak_topics:memUpdate.w?.length?memUpdate.w:undefined,strong_topics:memUpdate.s?.length?memUpdate.s:undefined,errors:memUpdate.e?.length?memUpdate.e:undefined,words_add:memUpdate.n||0,notes:memUpdate.note||undefined,session_summary:reply.slice(0,200)},env,userId,supabaseToken);

      if(userId&&supabaseToken){const last=[...messages].reverse().find(m=>m.role==='user');await fetch(`${env.SUPABASE_URL}/rest/v1/chat_messages`,{method:'POST',headers:{...H,Prefer:'return=minimal'},body:JSON.stringify([{user_id:userId,role:'user',content:last?.content||'',topic,mode},{user_id:userId,role:'assistant',content:reply,topic,mode,xp_gained:10}])}); }

      const abVariant=toolResults['get_ab_variant']?`${toolResults['get_ab_variant'].test_name}::${toolResults['get_ab_variant'].variant}`:null;
      const newState={...sessionState,difficulty:toolResults['update_difficulty']?.new_difficulty||sessionState?.difficulty||3,messages_count:(sessionState?.messages_count||0)+1};

      return new Response(JSON.stringify({reply,toolsUsed,abVariant,sessionState:newState}),{headers:CORS});
    } catch(err){
      return new Response(JSON.stringify({error:err.message}),{status:500,headers:CORS});
    }
  }
};
